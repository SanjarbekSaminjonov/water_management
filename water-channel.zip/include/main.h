//--------------------------------------------------
#define device_id "hackathon"
#define up_level 3.85
#define down_level 3.8
//--------------------------------------------------
#ifndef __MAIN_H_
#define __MAIN_H_
#define device_power PB14
#define booster_power PB15
#define gsm_power PA8
#define SD_CS PA4
#define TDS PB0
#define charging PB12
#define battery_pin PB1
#define setting_pin PB13
#define buzzer PB15
// timer
#define PIN_CLK PA11
#define PIN_DAT PA12
#define PIN_ENA PB8

#define gsm_enable digitalWrite(gsm_power, HIGH);
#define gsm_disable digitalWrite(gsm_power, LOW);
#define device_enable digitalWrite(device_power, HIGH);
#define device_disable digitalWrite(device_power, LOW);
#define battery analogRead(battery_pin)*6.6/1024
bool battery_low;// http://water.management.saminjonov.uz/api/channeldevices/messages/
char url[] = "AT+HTTPPARA=\"URL\",\"http://water.management.saminjonov.uz/api/channeldevices/messages/\"\r";
String longitude = "0.000007";
String latitude = "0.000007";
String gps_data;
String _latitude_, _longitude_;
long hour, minute, secound, dayOfWeek, dayOfMonth, month, year, oldCompassState, _compass_, netStatus;
unsigned long gettime;
bool re_settings;
bool take;
bool checkSD();
void play(uint16_t freq);
void gpio_init();
float getLevel();
long getCompass();
void checkCompass();
void wait(long time);
void connectGPRS();
void ShowSerialData();
bool sendData();
void sleep();
void displayTime();
void saveData(float level);
void getGPS();
byte calcDayOfWeek(long d, long m, long yyyy){
   
    int yy;         // Last 2 digits of the year (ie 2016 would be 16)
   
    int c;          // Century (ie 2016 would be 20)
    int mTable;     // Month value based on calculation table
    int SummedDate; // Add values combined in prep for Mod7 calc
    int DoW;        // Day of the week value (0-6)
    int leap;       // Leap Year or not
    int cTable;


    // Leap Year Calculation
    if((fmod(yyyy,4) == 0 && fmod(yyyy,100) != 0) || (fmod(yyyy,400) == 0))
    { leap = 1; }
    else 
    { leap = 0; }

    // Limit results to year 1900-2299 (to save memory)
    while(yyyy > 2299)
    { yyyy = yyyy - 400; }
    while(yyyy < 1900)
    { yyyy = yyyy + 400; }

    // Calculating century
    c = yyyy/100;

    // Calculating two digit year
    yy = fmod(yyyy, 100);

    // Century value based on Table
    if(c == 19) { cTable = 1; }
    if(c == 20) { cTable = 0; }
    if(c == 21) { cTable = 5; }
    if(c == 22) { cTable = 3; }

    // Jan and Feb calculations affected by leap years
    if(m == 1)
    { if(leap == 1) { mTable = 6; }
      else          { mTable = 0; }}
    if(m == 2)
    { if(leap == 1) { mTable = 2; }
      else          { mTable = 3; }}
    // Other months not affected and have set values
    if(m == 10) { mTable = 0; }
    if(m == 8) { mTable = 2; }
    if(m == 3 || m == 11) { mTable = 3; }
    if(m == 4 || m == 7) { mTable = 6; }
    if(m == 5) { mTable = 1; }
    if(m == 6) { mTable = 4; }
    if(m == 9 || m == 12) { mTable = 5; }

    // Enter the data into the formula
    SummedDate = d + mTable + yy + (yy/4) + cTable;
    
    // Find remainder
    DoW = fmod(SummedDate,7);
    return DoW;
}
#endif