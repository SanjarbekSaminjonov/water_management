#define device_power PB14
#define booster_power PB15
#define gsm_power PA8
#define gsm_enable digitalWrite(gsm_power, HIGH)
#define gsm_disable digitalWrite(gsm_power, LOW)