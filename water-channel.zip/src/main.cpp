#include <Arduino.h>
#include "STM32LowPower.h"
#include <EEPROM.h>
#include <SPI.h>
#include <SD.h>
#include <ArduinoJson.h>
#include <main.h>
#include <Ds1302.h>
#include <QMC5883LCompass.h>

HardwareSerial uart(PA10, PA9);
HardwareSerial modem(PA3, PA2);
HardwareSerial ultrasonic(PB11, PB10);

File myFile;

Ds1302 rtc(PIN_ENA, PIN_CLK, PIN_DAT);
QMC5883LCompass compass;

float level;

const static char* WeekDays[] =
{
  "Saturday",
  "Sunday",
  "Monday", 
  "Tuesday",
  "Wednesday",
  "Thursday",
  "Friday",
};

void setup(){
  gpio_init();
  LowPower.begin();
  // uart.begin(115200);
  delay(1000);
  // uart.println(F("BOOT"));
  modem.begin(9600);
  ultrasonic.begin(9600);
  compass.init();
  rtc.init();
  delay(100);
  oldCompassState = getCompass();
  Ds1302::DateTime now;
  rtc.getDateTime(&now);
  if (now.year == 0)
  { // 500 1
    Ds1302::DateTime dt = {
      .year = 18,
      .month = Ds1302::MONTH_OCT,
      .day = 3,
      .hour = 4,
      .minute = 0,
      .second = 0,
      .dow = Ds1302::DOW_TUE
    };
    rtc.setDateTime(&dt);
  }
  gsm_enable
  delay(10000);
  ShowSerialData();
  getGPS();
}

void loop(){
  gsm_enable
  if(!take){
    displayTime();
    device_enable
    delay(2000);
    level = getLevel();
    device_disable
  }else{
    ShowSerialData();
    getGPS();
  }
  unsigned long stimeout = millis() + 600000;
  while(!sendData()){
      if(stimeout < millis()) break; // 10 minut o'tgach uyquga ketadi
  }
  checkCompass();
  if (take)
  {
    oldCompassState = getCompass();
    return;
  }
  else
  {
    oldCompassState = getCompass();
  }
  sleep();
}

void gpio_init(){
  pinMode(device_power, OUTPUT);
  pinMode(booster_power, OUTPUT);
  pinMode(gsm_power, OUTPUT);
  pinMode(charging, INPUT);
  pinMode(buzzer, OUTPUT);
  pinMode(setting_pin, INPUT);
}

float getLevel(){
    // put your main code here, to run repeatedly:
    float level = 0.;
    while(ultrasonic.available()) ultrasonic.read();
    // uart.println(F("Ultrasonic start"));
    while(level < 1){
        uint16_t data[8];
        byte index = 0;
        bool received = false;
        bool start = false;
        float distance = 0.;
        if(ultrasonic.available()){
            // uart.println(F("Ultrasonic get"));
            data[0] = ultrasonic.read();
            data[1] = ultrasonic.read();
            data[2] = ultrasonic.read();
            data[3] = ultrasonic.read();
            data[4] = ultrasonic.read();
            data[5] = ultrasonic.read();
            data[6] = ultrasonic.read();
            data[7] = ultrasonic.read();
            delay(5);
            data[3] =  data[2];
            data[2] = data[1];
            data[1] = data[0];
            data[0] = 0xFF;
            if(((data[0] + data[1] + data[2])&0xFF) == data[3]){
                float distance = (data[1]*256 + data[2])/10.;
                if(distance < 1000) level = distance-5;
            }else{
                //// // uart.println("error");
            }
        }
    }
    return level;
}

long getCompass(){
  compass.read();
  return compass.getAzimuth();
}

void checkCompass(){
  _compass_ = getCompass();
  if(oldCompassState + 5 < _compass_ || oldCompassState - 5 > _compass_){
    take = true;
    // play(1000);
  }else{
    take = false;
  }
}

bool checkSD(){
  if(!SD.begin(SD_CS)){
      return false;
  }
  return true;
}

bool sendData() {
  unsigned long ktimeout = millis() + 120000;
  while(true){
    if(ktimeout < millis()) return false;
    modem.println(F("AT+CSQ\r"));
    delay(500);
    String text;
    text = modem.readString();
    if(text.indexOf("+CSQ:") > 0){
      netStatus = text.substring(text.indexOf(' '), text.indexOf(',')).toInt();
      //Serial1.println(text);
    }
    
    modem.println(F("AT+SAPBR=2,1\r")); /* Query the GPRS context */
    delay(200);
    
    text = modem.readString();
    long index = text.indexOf('\"');
    
    text = text.substring(index+1, text.length());
    index = text.indexOf('\"');
    text = text.substring(0, index);
  
    if(index < 0){
      connectGPRS();
      continue;
    }
    if(text == "0.0.0.0"){
      connectGPRS();
      continue;
    }
    break;
  }
  modem.println(F("AT+HTTPPARA=\"CID\",1\r"));
  delay(2000);
  ShowSerialData();
  modem.println(String(url));
  wait(1000);
  String text1 = modem.readString();
  if(text1.indexOf("ERROR") > 0){
    modem.println("AT+SAPBR=0,1");
    delay(1000);
    ShowSerialData();
    return false;
  }
 
  modem.println(F("AT+HTTPPARA=\"CONTENT\",\"application/json\"\r"));
  ShowSerialData();
  wait(4000);
  ShowSerialData();
 
  StaticJsonDocument<200> doc;
  String sendtoserver;
  if(!take){
    sendtoserver = "{\"taked\": \"" + String(take) + "\",\"h\": \""+String(level)+"\"," + (re_settings ? "\"re_settings\": false" : "\"re_settings\": true") + ",\"bat\": \""+String(battery)+"\",\"charging\": \"" + String(!digitalRead(charging)) + "\",\"net\": \""+String(netStatus)+"\",\"latitude\": \""+latitude+"\",\"longitude\": \""+longitude+"\",\"device_id\": \"" + device_id + "\"}";
  }else{
    sendtoserver = "{\"taked\": \"" + String(take) + "\",\"h\": \""+String(level)+"\"," + (re_settings ? "\"re_settings\": false" : "\"re_settings\": true") + ",\"bat\": \""+String(battery)+"\",\"charging\": \"" + String(!digitalRead(charging)) + "\",\"net\": \""+String(netStatus)+"\",\"latitude\": \""+latitude+"\",\"longitude\": \""+longitude+"\",\"device_id\": \"" + device_id + "\"}";
  }
  // uart.println(sendtoserver);
  modem.println("AT+HTTPDATA=" + String(sendtoserver.length()) + ",100000");
  ShowSerialData();
  wait(1000);
  delay(1000);
  ShowSerialData();
 
  modem.println(sendtoserver);
  delay(1000);
  ShowSerialData();
  wait(1000);
  ShowSerialData();
  modem.println(F("AT+HTTPACTION=1\r"));
  delay(1000);
  displayTime();
  ShowSerialData();
  delay(30000);
  ShowSerialData();
  modem.println(F("AT+HTTPREAD\r"));
  wait(10000);
  String tttt = modem.readString();
  play(2000);
  //// uart.println(tttt);
  long index1, index2;
  index1 = tttt.indexOf('{');
  index2 = tttt.indexOf('}');
  String json = tttt.substring(index1, index2+1);
  // uart.println("[" + json + "]");
  DeserializationError error = deserializeJson(doc, json);

  // Test if parsing succeeds.
  if (error) {
    // // uart.print(F("deserializeJson() failed: "));
    // // uart.println(error.f_str());
    modem.println(F("AT+HTTPTERM\r"));
    modem.println(F("AT+SAPBR=0,1\r"));
    delay(1000);
    return false;
  }
  String request = doc["request"];
  if(request != "success"){
    modem.println(F("AT+HTTPTERM\r"));
    modem.println(F("AT+SAPBR=0,1\r"));
    delay(1000);
    return false;
  }
  String dateTime = doc["datetime"];
  
  // // uart.println(dateTime);
  long x;
  x = dateTime.indexOf(':');
  uint8_t hour = dateTime.substring(0, x).toInt();
  dateTime = dateTime.substring(x+1, dateTime.length());
  
  x = dateTime.indexOf(':');
  uint8_t minute_ = dateTime.substring(0, x).toInt();
  dateTime = dateTime.substring(x+1, dateTime.length());

  x = dateTime.indexOf(' ');
  uint8_t secound = dateTime.substring(0, x).toInt();
  dateTime = dateTime.substring(x+1, dateTime.length());

  x = dateTime.indexOf('/');
  uint8_t day = dateTime.substring(0, x).toInt();
  dateTime = dateTime.substring(x+1, dateTime.length());

  x = dateTime.indexOf('/');
  uint8_t month = dateTime.substring(0, x).toInt();
  dateTime = dateTime.substring(x+1, dateTime.length());

  long year_ = dateTime.substring(2,4).toInt();
  // // uart.println(year_);
  if(minute_ != minute || year == 18){
    uint8_t _year_ = year_%100;
    Ds1302::DateTime dt = {
        .year = _year_,
        .month = month,
        .day = day,
        .hour = hour,
        .minute = minute_,
        .second = secound,
        .dow = calcDayOfWeek(day, month, year_)
    };

    rtc.setDateTime(&dt);
  }
  if(!re_settings) re_settings = true;
  modem.println(F("AT+HTTPTERM\r"));
  delay(2000);
  ShowSerialData();
  modem.println(F("AT+SAPBR=0,1\r"));
  return true;
}

void ShowSerialData()
{
  while(modem.available()!=0){
    char ll = modem.read();
    //uart.write(modem.read());
  }
  
}

void connectGPRS(){
  modem.println(F("AT"));
  wait(300);
 
  modem.println(F("AT+SAPBR=3,1,\"Contype\",\"GPRS\"\r"));
  wait(1000);
  ShowSerialData();
  modem.println(F("AT+SAPBR=3,1,\"APN\",\"INTERNET\"\r"));//APN
  wait(1000);
  ShowSerialData();
  modem.println(F("AT+SAPBR=1,1\r"));
  delay(6000);
  wait(10000);
  ShowSerialData();
  delay(1000);
  modem.println(F("AT+HTTPINIT\r"));
  wait(1000);
  ShowSerialData();  
}
void wait(long time){
  unsigned long timeout = millis() + time;
  while(!modem.available()){
    if(timeout < millis()) break;
  }
}

void sleep(){
  gsm_disable
  while(true){
    checkCompass();
    if(take){
      return;
    }
    displayTime();
    if(minute%2 == 0){
      device_enable
      delay(2000);
      if(checkSD()){
        float level;
        level = getLevel();
        saveData(level);
      }else{
      }
      if(battery < down_level && !battery_low){
        battery_low = true;
      }else if(battery > up_level && battery_low){
        battery_low = false;
      }
      if(!battery_low){
        break;
      }
      device_disable
    }
    // uart.println(F("Sleep"));
    delay(1000);
    LowPower.deepSleep(56000);
    delay(1000);
    // uart.println(F("wake up"));
  }
}

void displayTime()
{
  Ds1302::DateTime now;
  rtc.getDateTime(&now);

  static uint8_t last_second = 0;
  last_second = now.second;
  year = now.year;
  dayOfMonth = now.day;
  month = now.month;
  hour = now.hour;
  minute = now.minute;
  secound = now.second;
  // uart.print("20");
  // uart.print(now.year);    // 00-99
  
  // uart.print('-');
  // if (now.month < 10) // uart.print('0');
  // uart.print(now.month);   // 01-12
  // uart.print('-');
  // if (now.day < 10) // uart.print('0');
  // uart.print(now.day);     // 01-31
  // uart.print(' ');
  // uart.print(WeekDays[now.dow]); // 1-7
  // uart.print(' ');
  // if (now.hour < 10) // uart.print('0');
  // uart.print(now.hour);    // 00-23
  // uart.print(':');
  // if (now.minute < 10) // uart.print('0');
  // uart.print(now.minute);  // 00-59
  // uart.print(':');
  // if (now.second < 10) // uart.print('0');
  // uart.print(now.second);  // 00-59
  // uart.println();
}

void saveData(float level){
  myFile = SD.open("data.txt", FILE_WRITE);
  if (myFile) {
    String data1 = (dayOfMonth < 10 ? "0" + String(dayOfMonth) : String(dayOfMonth));
    data1 = data1 + "." + (month < 10 ? "0" + String(month) : String(month));
    data1 = data1 + ".20" + (year < 10 ? "0" + String(year) : String(year));
    data1 = data1 + "," + (hour < 10 ? "0" + String(hour) : String(hour));
    data1 = data1 + ":" + (minute < 10 ? "0" + String(minute) : String(minute));
    data1 = data1 + ":" + (secound < 10 ? "0" + String(secound) : String(secound));
    data1 = data1 + "," + String(level, 2) + ",";
    myFile.println(data1);
    myFile.close();
  }
}

void getGPS(){
  // uart.println("gps start ... ");
  delay(1000);
  modem.println("AT+CGNSPWR=1");
  delay(5000);
  ShowSerialData();
  modem.println("AT+CGNSSEQ=\"RMC\"");
  delay(1000);
  ShowSerialData();
  // modem.println("AT+CGNSIPR=\"9600\"");
  // delay(1000);
  // ShowSerialData();
  unsigned long timeout = millis() + 600000;
  while(true){
    if(millis() > timeout) break;
    modem.println("AT+CGNSINF");
    wait(1000);
    ShowSerialData();
    gps_data = modem.readString();
    // play(500);
    // uart.println(gps_data);
    int index = gps_data.indexOf("+CGNSINF: 1,");
    
    if(index < 0){
      modem.println("AT+CGNSPWR=1");
      delay(1000);
      continue;
    }
    
    gps_data = gps_data.substring(index+12, gps_data.length());
    //// // uart.println(gps_data);
    index = gps_data.indexOf(',');
    if(index < 0) continue;
    gps_data = gps_data.substring(index+1, gps_data.length());
    index = gps_data.indexOf(',');
    if(index < 0) continue;
    gps_data = gps_data.substring(index+1, gps_data.length());
    //// // uart.println(gps_data);
    index = gps_data.indexOf(',');
    if(index < 0) continue;
    _latitude_ = gps_data.substring(0, index);
    
    gps_data = gps_data.substring(index+1, gps_data.length());
    index = gps_data.indexOf(',');
    if(index < 0) continue;
    _longitude_ = gps_data.substring(0, index);
    if(_latitude_.length() > 7 && _latitude_.length() <= 9 && _longitude_.length() > 7 && _longitude_.length() <= 9){
      latitude = _latitude_;
      longitude = _longitude_;
      // uart.println(latitude + " " + longitude);
      break;
    }
  }
  
}
void play(uint16_t freq){
  digitalWrite(buzzer, HIGH);
  delay(freq);
  digitalWrite(buzzer, LOW);
}